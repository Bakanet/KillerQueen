﻿namespace miniPokemon
{
    public static class Fight
    {
        private static Pomon[] Team1;
        private static Pomon[] Team2;
    }
}