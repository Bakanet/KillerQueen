﻿using System.Collections.Generic;

namespace miniPokemon
{
    public class Team
    {
        #region Constructor

        #endregion

        #region Methods

        public void AvailablePokemon()
        {
            
        }



        #endregion
    }
}