﻿using System;
using System.Globalization;

namespace Exceptions
{
    internal class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}