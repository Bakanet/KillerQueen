﻿using System.Collections.Generic;
using EpitaSpaceProgram.ACDC;

namespace EpitaSpaceProgram
{
    public class DistanceJoint : IEntity
    {
        public DistanceJoint(Vector2 origin, Body body)
        {
            // FIXME
        }

        public void Update(double delta)
        {
            // FIXME
        }

        // Don't change this method.
        public IEnumerable<string> Serialize()
        {
            return new List<string>();
        }
    }
}