﻿using System;
using System.Collections.Generic;

namespace CheckIt
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Nope");
        }
    }
}