﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using Debugger;

namespace TP2
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            
        }
    }
}