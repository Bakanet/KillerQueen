﻿using System;
using System.Collections.Generic;

namespace Takuzu
{
    internal class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}
